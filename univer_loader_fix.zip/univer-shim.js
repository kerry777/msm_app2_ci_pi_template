/* univer-shim.js
 * Use this ONLY as a guard to avoid 'Univer is undefined' crashes when some third-party code
 * executes before the loader resolves. Prefer using UniverLoader.ensureUniverReady() instead.
 */
(function (global) {
  if (!('Univer' in global) && global.univer && global.univer.Univer) {
    global.Univer = global.univer.Univer;
  }
})(window);
