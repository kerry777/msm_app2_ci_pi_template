/* univer-loader.js
 * Robust loader & guard utilities for Univer-based apps.
 * How to use:
 * 1) Add data-univer attribute to <script> tags that load Univer bundles (local or CDN).
 * 2) Include this file AFTER those tags, or inline import it before calling your init code.
 * 3) Call await ensureUniverReady({ timeoutMs: 15000 }) before using Univer APIs.
 */

(function (global) {
  const STATE = {
    startedAt: Date.now(),
    loadedScripts: new Set(),
    waitingResolvers: [],
    waitingRejectors: [],
    timeoutHandle: null,
  };

  function getUniverGlobal() {
    // Try common global placements
    if (global.Univer) return global.Univer;
    if (global.univer && global.univer.Univer) return global.univer.Univer;
    // Some builds expose a namespace like window.univerjs
    if (global.univerjs && global.univerjs.Univer) return global.univerjs.Univer;
    return undefined;
  }

  function _resolveAllReady() {
    const U = getUniverGlobal();
    if (U) {
      STATE.waitingResolvers.splice(0).forEach((res) => res(U));
      if (STATE.timeoutHandle) clearTimeout(STATE.timeoutHandle);
      STATE.timeoutHandle = null;
      return true;
    }
    return false;
  }

  function observeTaggedScripts() {
    // Attach load/error handlers to scripts marked with data-univer
    const scripts = Array.from(document.querySelectorAll('script[data-univer]'));
    scripts.forEach((s) => {
      const key = s.getAttribute("src") || s.textContent.slice(0, 20);
      if (STATE.loadedScripts.has(key)) return;

      function onLoadOrError() {
        STATE.loadedScripts.add(key);
        // After any Univer script finishes, check if the global is present
        _resolveAllReady();
      }
      s.addEventListener('load', onLoadOrError, { once: true });
      s.addEventListener('error', onLoadOrError, { once: true });
    });
  }

  async function ensureUniverReady(opts = {}) {
    const timeoutMs = typeof opts.timeoutMs === "number" ? opts.timeoutMs : 15000;

    // Fast-path: already available
    const U0 = getUniverGlobal();
    if (U0) return U0;

    observeTaggedScripts();

    // If a script is still streaming, wait until it finishes or timeout
    const waitP = new Promise((resolve, reject) => {
      STATE.waitingResolvers.push(resolve);
      STATE.waitingRejectors.push(reject);
    });

    if (!STATE.timeoutHandle) {
      STATE.timeoutHandle = setTimeout(() => {
        const tried = Array.from(document.querySelectorAll('script[data-univer]')).map(s => s.getAttribute('src'));
        const detail = {
          message: "Univer global not found on window within timeout.",
          triedScripts: tried,
          now: new Date().toISOString(),
          elapsedMs: Date.now() - STATE.startedAt,
          location: global.location && global.location.href
        };
        const err = new Error("Univer 라이브러리가 로드되지 않았습니다 (timeout).");
        err.detail = detail;
        STATE.waitingRejectors.splice(0).forEach((rej) => rej(err));
      }, timeoutMs);
    }

    // In case the scripts already finished before we set handlers
    if (_resolveAllReady()) {
      return getUniverGlobal();
    }

    return waitP;
  }

  // Safe accessor that throws a clear error if Univer is still missing
  function requireUniver() {
    const U = getUniverGlobal();
    if (!U) {
      const err = new Error("Univer가 아직 window에 존재하지 않습니다.");
      err.hint = "ensureUniverReady()가 resolve된 다음에 Univer API를 사용하세요.";
      throw err;
    }
    return U;
  }

  // Expose small helpers
  global.UniverLoader = {
    ensureUniverReady,
    requireUniver,
    getUniverGlobal,
  };

})(window);
